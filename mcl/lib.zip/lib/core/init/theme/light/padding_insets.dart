import 'package:flutter/rendering.dart';

class PaddingInsets {
  final lowPaddingAll = EdgeInsets.all(5);
}
