import 'package:flutter/material.dart';

abstract class AppTheme {
  ThemeData? theme;
}
