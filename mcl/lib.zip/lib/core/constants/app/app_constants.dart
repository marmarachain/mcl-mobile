class ApplicationConstants {
  static const LANG_ASSET_PATH = 'assets/lang';
  static const FONT_FAMILY = 'Quicksand';
  static const APP_NAME = 'MCL';
}
