import 'package:stacked/stacked.dart';

class MclDetailTrackModel extends IndexTrackingViewModel {}
