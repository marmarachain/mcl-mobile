import 'package:mcl/app/app.logger.dart';
import 'package:mcl/utils/ssh.dart';

class SshConnectApi {
  final log = getLogger('SshConnectApi');
  // To connect with api without password
}
